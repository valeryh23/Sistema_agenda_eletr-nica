 

 var firebaseConfig = {
    apiKey: "AIzaSyBC_tp-JRsxcj8G5hhM_TCrjSGt1W5dfNE",
    authDomain: "agenda-de-contatos-2020.firebaseapp.com",
    databaseURL: "https://agenda-de-contatos-2020.firebaseio.com",
    projectId: "agenda-de-contatos-2020",
    storageBucket: "agenda-de-contatos-2020.appspot.com",
    messagingSenderId: "1016614000913",
    appId: "1:1016614000913:web:750e1baf6f67320ed794b0",
    measurementId: "G-FS84QY4S63"
  };
  // Initialize Firebase
  firebase.initializeApp(firebaseConfig);
  firebase.analytics();
