
Olá!Tudo bem?
Seguem as intruções sobre o projeto.

---> O Projeto teve foco no frontend, foi onde passei
mais tempo 

----> Plugins e linguagens usadas:

Bootstrap4, javascript, CSS e para fazer a conexão usei 
PHP e o firebase

São dois projetos, um front-end e um backend
estão separados

----> Para executar é preciso apenas descompactar a pasta e abrir os arquivos .html no navegador

Até mais! \o/